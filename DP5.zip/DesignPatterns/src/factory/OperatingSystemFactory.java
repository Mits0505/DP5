package factory;

import java.awt.Window;

import factory.phone.Android;
import factory.phone.IOS;
import factory.phone.OS;
import factory.phone.Windows;

public class OperatingSystemFactory {

	public OS getInstance(String osName){
		if(osName.equals("Open"))
			return new Android();
		else if(osName.equals("Closed"))
			return new IOS();
		else
			return new Windows();
	}
}
