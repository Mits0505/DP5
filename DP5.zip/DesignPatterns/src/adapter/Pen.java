package adapter;

public interface Pen {

	void write(String str);
}
