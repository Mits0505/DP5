package composite;

public interface Component {
	void showPrice();
}
