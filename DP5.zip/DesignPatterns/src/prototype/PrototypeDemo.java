package prototype;

public class PrototypeDemo {

	public static void main(String[] args) throws CloneNotSupportedException {
		BookShop bs = new BookShop();
		bs.setShopName("Aggarwals");
		bs.loadBooks();
		
		BookShop bs2 = (BookShop) bs.clone();
		bs2.setShopName("Guptas");
		
		bs.getBooks().remove(0);
		System.out.println(bs);
		System.out.println(bs2);
	}

}
