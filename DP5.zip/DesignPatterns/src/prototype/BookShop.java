package prototype;

import java.util.ArrayList;
import java.util.List;

public class BookShop implements Cloneable {
	private String shopName;
	List<Book> books = new ArrayList();
	public String getShopName() {
		return shopName;
	}
	public void setShopName(String shopName) {
		this.shopName = shopName;
	}
	public List<Book> getBooks() {
		return books;
	}
	public void setBooks(List<Book> books) {
		this.books = books;
	}
	
	public void loadBooks() {
		// Assume we are fetching the books from database.
		for (int i = 0; i < 10; i++) {
			Book b = new Book();
			b.setBid(i);
			b.setBname("book"+i);
			getBooks().add(b);
		}
		
	}	
	
	@Override
	protected BookShop clone() throws CloneNotSupportedException {
		// TODO Auto-generated method stub
		BookShop bs2 = new BookShop();
		for(Book b : this.getBooks()){
			bs2.getBooks().add(b);
		}
		
		return bs2;
	}
	@Override
	public String toString() {
		return "BookShop [shopName=" + shopName + ", books=" + books + "]";
	}

}
